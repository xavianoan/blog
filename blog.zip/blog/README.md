# Portfolio & Blog

A modern, full-stack portfolio and blog built with **Next.js 15**, **TypeScript**, **Tailwind CSS**, and **MySQL + Prisma ORM**.

## Features

- **Public site**: Home, About, Blog (list + detail), Projects (list + detail), Contact
- **Admin dashboard**: Secure login, post/project CRUD, rich text editor (Tiptap), categories, tags, messages, site settings
- **SEO**: Dynamic metadata, sitemap, robots.txt
- **Dark mode**: System-aware theme toggle
- **Image uploads**: Authenticated file upload API
- **Contact form**: Database storage + optional email via Nodemailer

## Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env` with your values:

```env
DATABASE_URL="mysql://user:password@localhost:3306/portfolio_blog"
NEXTAUTH_SECRET="your-random-secret-here"
NEXTAUTH_URL="http://localhost:3000"
ADMIN_EMAIL="admin@example.com"
ADMIN_PASSWORD="your-admin-password"
```

### 3. Set up the database

```bash
npm run db:push
npm run db:seed
```

### 4. Run the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

Admin panel: [http://localhost:3000/admin](http://localhost:3000/admin)

### 5. Build for production

```bash
npm run build
npm run start
```

## Environment Variables

| Variable | Description |
|---|---|
| `DATABASE_URL` | MySQL connection string |
| `NEXTAUTH_SECRET` | Random secret for NextAuth JWT signing |
| `NEXTAUTH_URL` | Full URL of your deployment |
| `ADMIN_EMAIL` | Admin login email (used by seed) |
| `ADMIN_PASSWORD` | Admin login password (used by seed) |
| `SMTP_HOST` | SMTP server host (optional) |
| `SMTP_PORT` | SMTP server port (optional) |
| `SMTP_USER` | SMTP username (optional) |
| `SMTP_PASS` | SMTP password (optional) |
| `SMTP_FROM` | From email address (optional) |

## Project Structure

```
src/
├── app/
│   ├── (public)/          # Public-facing pages
│   │   ├── page.tsx       # Home
│   │   ├── about/
│   │   ├── blog/
│   │   ├── projects/
│   │   └── contact/
│   ├── admin/             # Admin dashboard (protected)
│   │   ├── login/
│   │   ├── posts/
│   │   ├── projects/
│   │   ├── categories/
│   │   ├── tags/
│   │   ├── messages/
│   │   └── settings/
│   ├── api/               # API routes
│   │   ├── auth/
│   │   ├── contact/
│   │   ├── upload/
│   │   └── admin/
│   ├── sitemap.ts
│   └── robots.ts
├── components/
│   ├── admin/             # Admin UI components
│   ├── contact/
│   ├── layout/            # Navbar, Footer
│   ├── providers/
│   └── ui/
├── lib/
│   ├── auth.ts            # NextAuth config
│   ├── prisma.ts          # Prisma client
│   ├── settings.ts        # Site settings loader
│   └── utils.ts           # Utility functions
└── middleware.ts           # Auth middleware
prisma/
├── schema.prisma
└── seed.ts
```

## Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript (strict)
- **Styling**: Tailwind CSS + @tailwindcss/typography
- **Database**: MySQL via Prisma ORM
- **Auth**: NextAuth v5 (credentials provider)
- **Editor**: Tiptap (rich text)
- **Email**: Nodemailer
- **Icons**: Lucide React
