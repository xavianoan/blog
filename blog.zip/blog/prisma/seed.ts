import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  const adminEmail = process.env.ADMIN_EMAIL ?? "admin@example.com";
  const adminPassword = process.env.ADMIN_PASSWORD ?? "admin123";
  const hashedPassword = await bcrypt.hash(adminPassword, 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      name: "Admin",
      password: hashedPassword,
      role: "ADMIN",
    },
  });
  console.log(`✅ Admin user: ${admin.email}`);

  const defaultSettings = [
    { key: "siteTitle", value: "My Portfolio & Blog" },
    { key: "siteDescription", value: "Personal portfolio and blog — thoughts on code, design & life." },
    { key: "authorName", value: "Your Name" },
    { key: "authorBio", value: "Full-stack developer passionate about building great products." },
    { key: "authorAvatar", value: "" },
    { key: "twitterUrl", value: "" },
    { key: "githubUrl", value: "https://github.com" },
    { key: "linkedinUrl", value: "" },
    { key: "contactEmail", value: adminEmail },
    { key: "footerText", value: "© 2025 My Portfolio. All rights reserved." },
    { key: "heroTitle", value: "Hi, I'm Your Name 👋" },
    { key: "heroSubtitle", value: "Full-Stack Developer & UI/UX Enthusiast" },
    { key: "heroDescription", value: "I build fast, accessible and beautiful web experiences. Currently open to new opportunities." },
    { key: "aboutTitle", value: "About Me" },
    { key: "aboutContent", value: "<p>Write something about yourself here...</p>" },
    { key: "skills", value: JSON.stringify(["TypeScript", "React", "Next.js", "Node.js", "PostgreSQL", "Docker"]) },
  ];

  for (const setting of defaultSettings) {
    await prisma.siteSetting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }
  console.log(`✅ ${defaultSettings.length} site settings seeded`);

  const webCategory = await prisma.category.upsert({
    where: { slug: "web-development" },
    update: {},
    create: {
      name: "Web Development",
      slug: "web-development",
      description: "Articles about web development",
      color: "#6366f1",
    },
  });

  const designCategory = await prisma.category.upsert({
    where: { slug: "design" },
    update: {},
    create: {
      name: "Design",
      slug: "design",
      description: "Articles about design",
      color: "#ec4899",
    },
  });
  console.log("✅ Categories seeded");

  const tag1 = await prisma.tag.upsert({
    where: { slug: "nextjs" },
    update: {},
    create: { name: "Next.js", slug: "nextjs" },
  });

  const tag2 = await prisma.tag.upsert({
    where: { slug: "typescript" },
    update: {},
    create: { name: "TypeScript", slug: "typescript" },
  });
  console.log("✅ Tags seeded");

  const post = await prisma.post.upsert({
    where: { slug: "welcome-to-my-blog" },
    update: {},
    create: {
      title: "Welcome to My Blog",
      slug: "welcome-to-my-blog",
      excerpt: "This is my first blog post. Welcome!",
      content: "<h2>Hello World!</h2><p>Welcome to my personal blog. I'll be writing about web development, design, and everything in between. Stay tuned!</p>",
      status: "PUBLISHED",
      featured: true,
      readingTime: 1,
      categoryId: webCategory.id,
      publishedAt: new Date(),
    },
  });

  await prisma.postTag.upsert({
    where: { postId_tagId: { postId: post.id, tagId: tag1.id } },
    update: {},
    create: { postId: post.id, tagId: tag1.id },
  });
  console.log("✅ Sample post seeded");

  await prisma.project.upsert({
    where: { slug: "portfolio-blog" },
    update: {},
    create: {
      title: "Portfolio & Blog",
      slug: "portfolio-blog",
      description: "A full-stack portfolio and blog built with Next.js, TypeScript, Prisma and MySQL.",
      techStack: JSON.stringify(["Next.js", "TypeScript", "Prisma", "MySQL", "Tailwind CSS"]),
      demoUrl: "https://example.com",
      githubUrl: "https://github.com",
      featured: true,
      status: "PUBLISHED",
      order: 1,
    },
  });
  console.log("✅ Sample project seeded");

  console.log("🎉 Seeding complete!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
