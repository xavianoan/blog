"use client";

import { useState } from "react";
import { Loader2, Save } from "lucide-react";
import toast from "react-hot-toast";

type Props = { initialSettings: Record<string, string> };

const fields: {
  section: string;
  items: { key: string; label: string; type?: string; placeholder?: string; textarea?: boolean }[];
}[] = [
  {
    section: "General",
    items: [
      { key: "site_title", label: "Site Title", placeholder: "My Portfolio & Blog" },
      { key: "site_description", label: "Site Description", placeholder: "A short description of your site", textarea: true },
      { key: "site_url", label: "Site URL", placeholder: "https://example.com" },
    ],
  },
  {
    section: "Author",
    items: [
      { key: "author_name", label: "Author Name", placeholder: "Your Name" },
      { key: "author_email", label: "Author Email", type: "email", placeholder: "you@example.com" },
      { key: "author_bio", label: "Author Bio", placeholder: "A short bio about you", textarea: true },
      { key: "author_avatar", label: "Avatar URL", placeholder: "https://example.com/avatar.jpg" },
      { key: "author_location", label: "Location", placeholder: "City, Country" },
    ],
  },
  {
    section: "Social Links",
    items: [
      { key: "social_github", label: "GitHub", placeholder: "https://github.com/username" },
      { key: "social_twitter", label: "Twitter / X", placeholder: "https://twitter.com/username" },
      { key: "social_linkedin", label: "LinkedIn", placeholder: "https://linkedin.com/in/username" },
      { key: "social_instagram", label: "Instagram", placeholder: "https://instagram.com/username" },
      { key: "social_youtube", label: "YouTube", placeholder: "https://youtube.com/@channel" },
    ],
  },
  {
    section: "Contact",
    items: [
      { key: "contact_email", label: "Contact Email", type: "email", placeholder: "contact@example.com" },
      { key: "contact_phone", label: "Phone", placeholder: "+1 234 567 8900" },
    ],
  },
  {
    section: "SEO",
    items: [
      { key: "meta_title", label: "Default Meta Title", placeholder: "My Portfolio & Blog" },
      { key: "meta_description", label: "Default Meta Description", placeholder: "SEO description", textarea: true },
      { key: "og_image", label: "Default OG Image URL", placeholder: "https://example.com/og.jpg" },
    ],
  },
];

export function SettingsForm({ initialSettings }: Props) {
  const [settings, setSettings] = useState<Record<string, string>>(initialSettings);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success("Settings saved!");
    } catch {
      toast.error("Failed to save settings");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {fields.map(({ section, items }) => (
        <div key={section} className="card p-6 space-y-5">
          <h2 className="font-semibold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-3">
            {section}
          </h2>
          <div className="space-y-4">
            {items.map(({ key, label, type, placeholder, textarea }) => (
              <div key={key}>
                <label className="label">{label}</label>
                {textarea ? (
                  <textarea
                    rows={3}
                    value={settings[key] ?? ""}
                    onChange={(e) => setSettings((p) => ({ ...p, [key]: e.target.value }))}
                    placeholder={placeholder}
                    className="input resize-none"
                  />
                ) : (
                  <input
                    type={type ?? "text"}
                    value={settings[key] ?? ""}
                    onChange={(e) => setSettings((p) => ({ ...p, [key]: e.target.value }))}
                    placeholder={placeholder}
                    className="input"
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="sticky bottom-4">
        <button
          onClick={handleSave}
          disabled={loading}
          className="btn-primary shadow-lg"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
          Save Settings
        </button>
      </div>
    </div>
  );
}
