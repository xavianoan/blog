"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { generateSlug } from "@/lib/utils";
import toast from "react-hot-toast";
import { Loader2, Save, Upload, X, Plus } from "lucide-react";
import Image from "next/image";

const TiptapEditor = dynamic(
  () => import("@/components/admin/TiptapEditor").then((m) => m.TiptapEditor),
  { ssr: false, loading: () => <div className="h-64 bg-slate-100 dark:bg-slate-800 rounded-xl animate-pulse" /> }
);

type ProjectFormProps = {
  initialData?: {
    id: string;
    title: string;
    slug: string;
    description: string;
    content: string | null;
    coverImage: string | null;
    demoUrl: string | null;
    githubUrl: string | null;
    techStack: string[];
    featured: boolean;
    order: number;
    status: "DRAFT" | "PUBLISHED";
  };
};

export function ProjectForm({ initialData }: ProjectFormProps) {
  const router = useRouter();
  const isEdit = !!initialData;

  const [loading, setLoading] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [techInput, setTechInput] = useState("");
  const [form, setForm] = useState({
    title: initialData?.title ?? "",
    slug: initialData?.slug ?? "",
    description: initialData?.description ?? "",
    content: initialData?.content ?? "",
    coverImage: initialData?.coverImage ?? "",
    demoUrl: initialData?.demoUrl ?? "",
    githubUrl: initialData?.githubUrl ?? "",
    techStack: initialData?.techStack ?? [] as string[],
    featured: initialData?.featured ?? false,
    order: initialData?.order ?? 0,
    status: initialData?.status ?? "PUBLISHED" as "DRAFT" | "PUBLISHED",
  });

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingCover(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Upload failed");
      const data = await res.json() as { url: string };
      setForm((p) => ({ ...p, coverImage: data.url }));
    } catch {
      toast.error("Cover image upload failed");
    } finally {
      setUploadingCover(false);
      e.target.value = "";
    }
  };

  const addTech = () => {
    const t = techInput.trim();
    if (t && !form.techStack.includes(t)) {
      setForm((p) => ({ ...p, techStack: [...p.techStack, t] }));
    }
    setTechInput("");
  };

  const removeTech = (tech: string) => {
    setForm((p) => ({ ...p, techStack: p.techStack.filter((t) => t !== tech) }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const slug = form.slug.trim() || generateSlug(form.title);
    try {
      const url = isEdit ? `/api/admin/projects/${initialData!.id}` : "/api/admin/projects";
      const method = isEdit ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, slug }),
      });
      if (!res.ok) throw new Error("Request failed");
      toast.success(isEdit ? "Project updated!" : "Project created!");
      router.push("/admin/projects");
      router.refresh();
    } catch {
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-5">
          <div>
            <label className="label">Title *</label>
            <input type="text" required value={form.title}
              onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
              placeholder="Project title" className="input text-lg font-medium" />
          </div>
          <div>
            <label className="label">Slug</label>
            <input type="text" value={form.slug}
              onChange={(e) => setForm((p) => ({ ...p, slug: e.target.value }))}
              placeholder="project-slug" className="input font-mono text-sm" />
          </div>
          <div>
            <label className="label">Description *</label>
            <textarea rows={3} required value={form.description}
              onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
              placeholder="Brief project description" className="input resize-none" />
          </div>
          <div>
            <label className="label">Detailed Content (optional)</label>
            <TiptapEditor content={form.content} onChange={(html) => setForm((p) => ({ ...p, content: html }))} />
          </div>
        </div>

        <div className="space-y-5">
          {/* Publish */}
          <div className="card p-5 space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-white">Publish</h3>
            <div>
              <label className="label">Status</label>
              <select value={form.status}
                onChange={(e) => setForm((p) => ({ ...p, status: e.target.value as "DRAFT" | "PUBLISHED" }))}
                className="input">
                <option value="PUBLISHED">Published</option>
                <option value="DRAFT">Draft</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label text-xs">Order</label>
                <input type="number" value={form.order}
                  onChange={(e) => setForm((p) => ({ ...p, order: parseInt(e.target.value) || 0 }))}
                  className="input text-sm" />
              </div>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.featured}
                onChange={(e) => setForm((p) => ({ ...p, featured: e.target.checked }))}
                className="rounded border-slate-300" />
              <span className="text-sm text-slate-700 dark:text-slate-300">Featured project</span>
            </label>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center">
              {loading ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
              {isEdit ? "Update Project" : "Save Project"}
            </button>
          </div>

          {/* Cover */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-white">Cover Image</h3>
            {form.coverImage ? (
              <div className="relative">
                <Image src={form.coverImage} alt="Cover" width={400} height={200}
                  className="w-full h-36 object-cover rounded-xl" />
                <button type="button" onClick={() => setForm((p) => ({ ...p, coverImage: "" }))}
                  className="absolute top-2 right-2 p-1 bg-white dark:bg-slate-800 rounded-full shadow text-slate-500 hover:text-red-500">
                  <X size={14} />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center h-28 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl cursor-pointer hover:border-brand-400 transition-colors">
                {uploadingCover ? <Loader2 size={20} className="animate-spin text-slate-400" /> : (
                  <><Upload size={20} className="text-slate-400 mb-2" /><span className="text-sm text-slate-400">Upload cover</span></>
                )}
                <input type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} />
              </label>
            )}
            <input type="url" value={form.coverImage}
              onChange={(e) => setForm((p) => ({ ...p, coverImage: e.target.value }))}
              placeholder="https://..." className="input text-sm" />
          </div>

          {/* Links */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-white">Links</h3>
            <div>
              <label className="label text-xs">Demo URL</label>
              <input type="url" value={form.demoUrl}
                onChange={(e) => setForm((p) => ({ ...p, demoUrl: e.target.value }))}
                placeholder="https://..." className="input text-sm" />
            </div>
            <div>
              <label className="label text-xs">GitHub URL</label>
              <input type="url" value={form.githubUrl}
                onChange={(e) => setForm((p) => ({ ...p, githubUrl: e.target.value }))}
                placeholder="https://github.com/..." className="input text-sm" />
            </div>
          </div>

          {/* Tech Stack */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-white">Tech Stack</h3>
            <div className="flex gap-2">
              <input type="text" value={techInput}
                onChange={(e) => setTechInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTech(); } }}
                placeholder="e.g. Next.js" className="input text-sm flex-1" />
              <button type="button" onClick={addTech} className="btn-secondary px-3">
                <Plus size={16} />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {form.techStack.map((tech) => (
                <span key={tech} className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs bg-brand-50 dark:bg-brand-950 text-brand-600 dark:text-brand-400 border border-brand-100 dark:border-brand-900">
                  {tech}
                  <button type="button" onClick={() => removeTech(tech)} className="hover:text-red-500 ml-0.5">
                    <X size={11} />
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}
