"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import Link from "@tiptap/extension-link";
import Image from "@tiptap/extension-image";
import Placeholder from "@tiptap/extension-placeholder";
import CodeBlockLowlight from "@tiptap/extension-code-block-lowlight";
import { common, createLowlight } from "lowlight";
import { useCallback, useRef } from "react";
import {
  Bold,
  Italic,
  UnderlineIcon,
  Strikethrough,
  Code,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Quote,
  Minus,
  LinkIcon,
  ImageIcon,
  Undo,
  Redo,
  Code2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import toast from "react-hot-toast";

const lowlight = createLowlight(common);

type Props = {
  content: string;
  onChange: (html: string) => void;
};

type ToolbarButtonProps = {
  onClick: () => void;
  active?: boolean;
  disabled?: boolean;
  title: string;
  children: React.ReactNode;
};

function ToolbarButton({ onClick, active, disabled, title, children }: ToolbarButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={cn(
        "p-1.5 rounded-lg transition-colors",
        active
          ? "bg-brand-100 dark:bg-brand-900 text-brand-600 dark:text-brand-400"
          : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700",
        disabled && "opacity-30 cursor-not-allowed"
      )}
    >
      {children}
    </button>
  );
}

export function TiptapEditor({ content, onChange }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ codeBlock: false }),
      Underline,
      Link.configure({ openOnClick: false }),
      Image.configure({ HTMLAttributes: { class: "rounded-xl max-w-full" } }),
      Placeholder.configure({ placeholder: "Write your content here..." }),
      CodeBlockLowlight.configure({ lowlight }),
    ],
    content,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      attributes: { class: "focus:outline-none" },
    },
  });

  const setLink = useCallback(() => {
    if (!editor) return;
    const previousUrl = editor.getAttributes("link").href as string;
    const url = window.prompt("URL", previousUrl);
    if (url === null) return;
    if (url === "") {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
      return;
    }
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  }, [editor]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editor) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      if (!res.ok) throw new Error("Upload failed");
      const data = await res.json() as { url: string };
      editor.chain().focus().setImage({ src: data.url }).run();
    } catch {
      toast.error("Image upload failed");
    }
    e.target.value = "";
  };

  if (!editor) return null;

  const toolbarGroups = [
    [
      { icon: <Undo size={15} />, action: () => editor.chain().focus().undo().run(), title: "Undo", disabled: !editor.can().undo() },
      { icon: <Redo size={15} />, action: () => editor.chain().focus().redo().run(), title: "Redo", disabled: !editor.can().redo() },
    ],
    [
      { icon: <Heading1 size={15} />, action: () => editor.chain().focus().toggleHeading({ level: 1 }).run(), title: "H1", active: editor.isActive("heading", { level: 1 }) },
      { icon: <Heading2 size={15} />, action: () => editor.chain().focus().toggleHeading({ level: 2 }).run(), title: "H2", active: editor.isActive("heading", { level: 2 }) },
      { icon: <Heading3 size={15} />, action: () => editor.chain().focus().toggleHeading({ level: 3 }).run(), title: "H3", active: editor.isActive("heading", { level: 3 }) },
    ],
    [
      { icon: <Bold size={15} />, action: () => editor.chain().focus().toggleBold().run(), title: "Bold", active: editor.isActive("bold") },
      { icon: <Italic size={15} />, action: () => editor.chain().focus().toggleItalic().run(), title: "Italic", active: editor.isActive("italic") },
      { icon: <UnderlineIcon size={15} />, action: () => editor.chain().focus().toggleUnderline().run(), title: "Underline", active: editor.isActive("underline") },
      { icon: <Strikethrough size={15} />, action: () => editor.chain().focus().toggleStrike().run(), title: "Strike", active: editor.isActive("strike") },
    ],
    [
      { icon: <List size={15} />, action: () => editor.chain().focus().toggleBulletList().run(), title: "Bullet list", active: editor.isActive("bulletList") },
      { icon: <ListOrdered size={15} />, action: () => editor.chain().focus().toggleOrderedList().run(), title: "Ordered list", active: editor.isActive("orderedList") },
      { icon: <Quote size={15} />, action: () => editor.chain().focus().toggleBlockquote().run(), title: "Blockquote", active: editor.isActive("blockquote") },
      { icon: <Minus size={15} />, action: () => editor.chain().focus().setHorizontalRule().run(), title: "Horizontal rule" },
    ],
    [
      { icon: <Code size={15} />, action: () => editor.chain().focus().toggleCode().run(), title: "Inline code", active: editor.isActive("code") },
      { icon: <Code2 size={15} />, action: () => editor.chain().focus().toggleCodeBlock().run(), title: "Code block", active: editor.isActive("codeBlock") },
    ],
    [
      { icon: <LinkIcon size={15} />, action: setLink, title: "Set link", active: editor.isActive("link") },
      { icon: <ImageIcon size={15} />, action: () => fileInputRef.current?.click(), title: "Insert image" },
    ],
  ];

  return (
    <div className="tiptap-editor border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-1 px-3 py-2 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
        {toolbarGroups.map((group, gi) => (
          <div key={gi} className={cn("flex items-center gap-0.5", gi > 0 && "pl-2 border-l border-slate-200 dark:border-slate-700")}>
            {group.map((item, i) => (
              <ToolbarButton
                key={i}
                onClick={item.action}
                active={"active" in item ? item.active : false}
                disabled={"disabled" in item ? item.disabled : false}
                title={item.title}
              >
                {item.icon}
              </ToolbarButton>
            ))}
          </div>
        ))}
      </div>

      {/* Editor */}
      <EditorContent editor={editor} className="min-h-[400px] p-4 text-sm text-slate-900 dark:text-slate-100" />

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleImageUpload}
      />
    </div>
  );
}
