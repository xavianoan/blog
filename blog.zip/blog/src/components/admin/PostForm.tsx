"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { generateSlug, calculateReadingTime } from "@/lib/utils";
import toast from "react-hot-toast";
import { Loader2, Save, Upload, X } from "lucide-react";
import Image from "next/image";

const TiptapEditor = dynamic(
  () => import("@/components/admin/TiptapEditor").then((m) => m.TiptapEditor),
  { ssr: false, loading: () => <div className="h-96 bg-slate-100 dark:bg-slate-800 rounded-xl animate-pulse" /> }
);

type Category = { id: string; name: string };
type Tag = { id: string; name: string };

type PostFormProps = {
  categories: Category[];
  tags: Tag[];
  initialData?: {
    id: string;
    title: string;
    slug: string;
    excerpt: string | null;
    content: string;
    coverImage: string | null;
    status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
    featured: boolean;
    categoryId: string | null;
    tagIds: string[];
    metaTitle: string | null;
    metaDescription: string | null;
  };
};

export function PostForm({ categories, tags, initialData }: PostFormProps) {
  const router = useRouter();
  const isEdit = !!initialData;

  const [loading, setLoading] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [form, setForm] = useState({
    title: initialData?.title ?? "",
    slug: initialData?.slug ?? "",
    excerpt: initialData?.excerpt ?? "",
    content: initialData?.content ?? "",
    coverImage: initialData?.coverImage ?? "",
    status: initialData?.status ?? "DRAFT",
    featured: initialData?.featured ?? false,
    categoryId: initialData?.categoryId ?? "",
    tagIds: initialData?.tagIds ?? [] as string[],
    metaTitle: initialData?.metaTitle ?? "",
    metaDescription: initialData?.metaDescription ?? "",
  });

  useEffect(() => {
    if (!isEdit && form.title && !form.slug) {
      setForm((p) => ({ ...p, slug: generateSlug(p.title) }));
    }
  }, [form.title, isEdit, form.slug]);

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingCover(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Upload failed");
      const data = await res.json() as { url: string };
      setForm((p) => ({ ...p, coverImage: data.url }));
    } catch {
      toast.error("Cover image upload failed");
    } finally {
      setUploadingCover(false);
      e.target.value = "";
    }
  };

  const toggleTag = (tagId: string) => {
    setForm((p) => ({
      ...p,
      tagIds: p.tagIds.includes(tagId)
        ? p.tagIds.filter((id) => id !== tagId)
        : [...p.tagIds, tagId],
    }));
  };

  const handleSubmit = async (e: React.FormEvent, status?: "DRAFT" | "PUBLISHED") => {
    e.preventDefault();
    setLoading(true);
    const payload = {
      ...form,
      status: status ?? form.status,
      readingTime: calculateReadingTime(form.content),
    };
    try {
      const url = isEdit ? `/api/admin/posts/${initialData!.id}` : "/api/admin/posts";
      const method = isEdit ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.json() as { error: unknown };
        throw new Error(String(err.error));
      }
      toast.success(isEdit ? "Post updated!" : "Post created!");
      router.push("/admin/posts");
      router.refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={(e) => handleSubmit(e)} className="space-y-6">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="xl:col-span-2 space-y-5">
          <div>
            <label className="label">Title *</label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
              placeholder="Post title"
              className="input text-lg font-medium"
            />
          </div>

          <div>
            <label className="label">Slug</label>
            <input
              type="text"
              value={form.slug}
              onChange={(e) => setForm((p) => ({ ...p, slug: e.target.value }))}
              placeholder="post-slug"
              className="input font-mono text-sm"
            />
          </div>

          <div>
            <label className="label">Excerpt</label>
            <textarea
              rows={2}
              value={form.excerpt}
              onChange={(e) => setForm((p) => ({ ...p, excerpt: e.target.value }))}
              placeholder="Short description shown in post lists"
              className="input resize-none"
            />
          </div>

          <div>
            <label className="label">Content *</label>
            <TiptapEditor
              content={form.content}
              onChange={(html) => setForm((p) => ({ ...p, content: html }))}
            />
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-5">
          {/* Publish */}
          <div className="card p-5 space-y-4">
            <h3 className="font-semibold text-slate-900 dark:text-white">Publish</h3>
            <div>
              <label className="label">Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm((p) => ({ ...p, status: e.target.value as "DRAFT" | "PUBLISHED" | "ARCHIVED" }))}
                className="input"
              >
                <option value="DRAFT">Draft</option>
                <option value="PUBLISHED">Published</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={form.featured}
                onChange={(e) => setForm((p) => ({ ...p, featured: e.target.checked }))}
                className="rounded border-slate-300"
              />
              <span className="text-sm text-slate-700 dark:text-slate-300">Featured post</span>
            </label>
            <div className="flex gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
              <button
                type="button"
                disabled={loading}
                onClick={(e) => handleSubmit(e, "DRAFT")}
                className="btn-secondary flex-1 justify-center"
              >
                Save Draft
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={(e) => handleSubmit(e, "PUBLISHED")}
                className="btn-primary flex-1 justify-center"
              >
                {loading ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
                Publish
              </button>
            </div>
          </div>

          {/* Cover Image */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-white">Cover Image</h3>
            {form.coverImage ? (
              <div className="relative">
                <Image
                  src={form.coverImage}
                  alt="Cover"
                  width={400}
                  height={200}
                  className="w-full h-40 object-cover rounded-xl"
                />
                <button
                  type="button"
                  onClick={() => setForm((p) => ({ ...p, coverImage: "" }))}
                  className="absolute top-2 right-2 p-1 bg-white dark:bg-slate-800 rounded-full shadow text-slate-500 hover:text-red-500"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center h-32 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl cursor-pointer hover:border-brand-400 transition-colors">
                {uploadingCover ? (
                  <Loader2 size={20} className="animate-spin text-slate-400" />
                ) : (
                  <>
                    <Upload size={20} className="text-slate-400 mb-2" />
                    <span className="text-sm text-slate-400">Upload cover image</span>
                  </>
                )}
                <input type="file" accept="image/*" className="hidden" onChange={handleCoverUpload} />
              </label>
            )}
            <div>
              <label className="label text-xs">Or paste URL</label>
              <input
                type="url"
                value={form.coverImage}
                onChange={(e) => setForm((p) => ({ ...p, coverImage: e.target.value }))}
                placeholder="https://..."
                className="input text-sm"
              />
            </div>
          </div>

          {/* Category */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-white">Category</h3>
            <select
              value={form.categoryId}
              onChange={(e) => setForm((p) => ({ ...p, categoryId: e.target.value }))}
              className="input"
            >
              <option value="">No category</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
              ))}
            </select>
          </div>

          {/* Tags */}
          {tags.length > 0 && (
            <div className="card p-5 space-y-3">
              <h3 className="font-semibold text-slate-900 dark:text-white">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <button
                    key={tag.id}
                    type="button"
                    onClick={() => toggleTag(tag.id)}
                    className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                      form.tagIds.includes(tag.id)
                        ? "bg-brand-500 text-white border-brand-500"
                        : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-brand-400"
                    }`}
                  >
                    {tag.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* SEO */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-white">SEO</h3>
            <div>
              <label className="label text-xs">Meta Title</label>
              <input
                type="text"
                value={form.metaTitle}
                onChange={(e) => setForm((p) => ({ ...p, metaTitle: e.target.value }))}
                placeholder="SEO title (defaults to post title)"
                className="input text-sm"
              />
            </div>
            <div>
              <label className="label text-xs">Meta Description</label>
              <textarea
                rows={3}
                value={form.metaDescription}
                onChange={(e) => setForm((p) => ({ ...p, metaDescription: e.target.value }))}
                placeholder="SEO description (defaults to excerpt)"
                className="input text-sm resize-none"
              />
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}
