"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2, Loader2 } from "lucide-react";
import toast from "react-hot-toast";

type Tag = { id: string; name: string; slug: string; _count: { posts: number } };

export function TagsManager({ initialTags }: { initialTags: Tag[] }) {
  const router = useRouter();
  const [tags, setTags] = useState(initialTags);
  const [loading, setLoading] = useState<string | null>(null);
  const [input, setInput] = useState("");

  const handleCreate = async () => {
    const name = input.trim();
    if (!name) return;
    setLoading("create");
    try {
      const res = await fetch("/api/admin/tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (!res.ok) throw new Error("Failed");
      const tag = await res.json() as Tag;
      setTags((p) => [...p, { ...tag, _count: { posts: 0 } }]);
      setInput("");
      toast.success("Tag created");
      router.refresh();
    } catch {
      toast.error("Failed to create tag");
    } finally {
      setLoading(null);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Delete tag "${name}"?`)) return;
    setLoading(id);
    try {
      const res = await fetch(`/api/admin/tags/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed");
      setTags((p) => p.filter((t) => t.id !== id));
      toast.success("Tag deleted");
    } catch {
      toast.error("Failed to delete tag");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleCreate(); } }}
          placeholder="New tag name"
          className="input flex-1"
        />
        <button onClick={handleCreate} disabled={loading === "create"} className="btn-primary px-4">
          {loading === "create" ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />}
          Add Tag
        </button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Name</th>
              <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400 hidden sm:table-cell">Slug</th>
              <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400 hidden sm:table-cell">Posts</th>
              <th className="text-right px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            {tags.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-slate-400">No tags yet</td>
              </tr>
            ) : (
              tags.map((tag) => (
                <tr key={tag.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{tag.name}</td>
                  <td className="px-4 py-3 hidden sm:table-cell text-slate-400 font-mono text-xs">{tag.slug}</td>
                  <td className="px-4 py-3 hidden sm:table-cell text-slate-500">{tag._count.posts}</td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => handleDelete(tag.id, tag.name)}
                      disabled={loading === tag.id}
                      className="btn-ghost p-2 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      {loading === tag.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
