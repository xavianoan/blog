"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Pencil, Trash2, Loader2, Check, X } from "lucide-react";
import toast from "react-hot-toast";

type Category = { id: string; name: string; slug: string; color: string | null; description: string | null; _count: { posts: number } };

export function CategoriesManager({ initialCategories }: { initialCategories: Category[] }) {
  const router = useRouter();
  const [categories, setCategories] = useState(initialCategories);
  const [loading, setLoading] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);

  const emptyForm = { name: "", slug: "", description: "", color: "#6366f1" };
  const [newForm, setNewForm] = useState(emptyForm);
  const [editForm, setEditForm] = useState(emptyForm);

  const handleCreate = async () => {
    if (!newForm.name.trim()) return;
    setLoading("create");
    try {
      const res = await fetch("/api/admin/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newForm),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success("Category created");
      setShowNew(false);
      setNewForm(emptyForm);
      router.refresh();
      const data = await res.json() as Category;
      setCategories((p) => [...p, { ...data, _count: { posts: 0 } }]);
    } catch {
      toast.error("Failed to create category");
    } finally {
      setLoading(null);
    }
  };

  const handleUpdate = async (id: string) => {
    setLoading(id);
    try {
      const res = await fetch(`/api/admin/categories/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editForm),
      });
      if (!res.ok) throw new Error("Failed");
      toast.success("Category updated");
      setEditingId(null);
      router.refresh();
    } catch {
      toast.error("Failed to update category");
    } finally {
      setLoading(null);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Delete category "${name}"?`)) return;
    setLoading(id + "-del");
    try {
      const res = await fetch(`/api/admin/categories/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed");
      toast.success("Category deleted");
      setCategories((p) => p.filter((c) => c.id !== id));
    } catch {
      toast.error("Failed to delete category");
    } finally {
      setLoading(null);
    }
  };

  const startEdit = (cat: Category) => {
    setEditForm({ name: cat.name, slug: cat.slug, description: cat.description ?? "", color: cat.color ?? "#6366f1" });
    setEditingId(cat.id);
  };

  return (
    <div className="space-y-4">
      <button onClick={() => setShowNew(true)} className="btn-primary">
        <Plus size={16} /> New Category
      </button>

      {showNew && (
        <div className="card p-5 space-y-3">
          <h3 className="font-semibold text-slate-900 dark:text-white">New Category</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label text-xs">Name</label>
              <input type="text" value={newForm.name} onChange={(e) => setNewForm((p) => ({ ...p, name: e.target.value }))} className="input" placeholder="Category name" />
            </div>
            <div>
              <label className="label text-xs">Color</label>
              <div className="flex gap-2">
                <input type="color" value={newForm.color} onChange={(e) => setNewForm((p) => ({ ...p, color: e.target.value }))} className="h-10 w-16 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer" />
                <input type="text" value={newForm.color} onChange={(e) => setNewForm((p) => ({ ...p, color: e.target.value }))} className="input flex-1 font-mono text-sm" />
              </div>
            </div>
          </div>
          <div>
            <label className="label text-xs">Description</label>
            <input type="text" value={newForm.description} onChange={(e) => setNewForm((p) => ({ ...p, description: e.target.value }))} className="input" placeholder="Optional description" />
          </div>
          <div className="flex gap-2">
            <button onClick={handleCreate} disabled={loading === "create"} className="btn-primary">
              {loading === "create" ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
              Save
            </button>
            <button onClick={() => { setShowNew(false); setNewForm(emptyForm); }} className="btn-secondary"><X size={15} /> Cancel</button>
          </div>
        </div>
      )}

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Name</th>
              <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400 hidden sm:table-cell">Posts</th>
              <th className="text-right px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            {categories.map((cat) => (
              <tr key={cat.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <td className="px-4 py-3">
                  {editingId === cat.id ? (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <input type="text" value={editForm.name} onChange={(e) => setEditForm((p) => ({ ...p, name: e.target.value }))} className="input text-sm" />
                        <div className="flex gap-1">
                          <input type="color" value={editForm.color} onChange={(e) => setEditForm((p) => ({ ...p, color: e.target.value }))} className="h-9 w-12 rounded-lg border border-slate-200 dark:border-slate-700" />
                          <input type="text" value={editForm.color} onChange={(e) => setEditForm((p) => ({ ...p, color: e.target.value }))} className="input text-xs font-mono" />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => handleUpdate(cat.id)} disabled={loading === cat.id} className="btn-primary text-xs px-3 py-1.5">
                          {loading === cat.id ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />} Save
                        </button>
                        <button onClick={() => setEditingId(null)} className="btn-secondary text-xs px-3 py-1.5"><X size={12} /> Cancel</button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: cat.color ?? "#6366f1" }} />
                      <span className="font-medium text-slate-900 dark:text-white">{cat.name}</span>
                      <span className="text-slate-400 font-mono text-xs">/{cat.slug}</span>
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 hidden sm:table-cell text-slate-500">{cat._count.posts}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => startEdit(cat)} className="btn-ghost p-1.5 text-slate-400"><Pencil size={14} /></button>
                    <button onClick={() => handleDelete(cat.id, cat.name)} disabled={loading === cat.id + "-del"} className="btn-ghost p-1.5 text-slate-400 hover:text-red-500">
                      {loading === cat.id + "-del" ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
