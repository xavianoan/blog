"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Mail, Check, Archive, Trash2, Loader2 } from "lucide-react";
import toast from "react-hot-toast";

type Props = {
  id: string;
  status: string;
  email: string;
};

export function MessageActions({ id, status, email }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState<string | null>(null);

  const updateStatus = async (newStatus: string) => {
    setLoading(newStatus);
    try {
      const res = await fetch(`/api/admin/messages/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      if (!res.ok) throw new Error("Failed");
      router.refresh();
    } catch {
      toast.error("Failed to update message");
    } finally {
      setLoading(null);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Delete this message?")) return;
    setLoading("delete");
    try {
      const res = await fetch(`/api/admin/messages/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed");
      toast.success("Message deleted");
      router.refresh();
    } catch {
      toast.error("Failed to delete message");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="flex items-center gap-1 flex-shrink-0">
      {status !== "READ" && status !== "REPLIED" && (
        <button
          onClick={() => updateStatus("READ")}
          disabled={!!loading}
          className="btn-ghost p-2 text-slate-400 hover:text-brand-500 transition-colors"
          title="Mark as read"
        >
          {loading === "READ" ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
        </button>
      )}
      <a
        href={`mailto:${email}`}
        className="btn-ghost p-2 text-slate-400 hover:text-brand-500 transition-colors"
        title="Reply via email"
        onClick={() => updateStatus("REPLIED")}
      >
        <Mail size={14} />
      </a>
      {status !== "ARCHIVED" && (
        <button
          onClick={() => updateStatus("ARCHIVED")}
          disabled={!!loading}
          className="btn-ghost p-2 text-slate-400 hover:text-amber-500 transition-colors"
          title="Archive"
        >
          {loading === "ARCHIVED" ? <Loader2 size={14} className="animate-spin" /> : <Archive size={14} />}
        </button>
      )}
      <button
        onClick={handleDelete}
        disabled={!!loading}
        className="btn-ghost p-2 text-slate-400 hover:text-red-500 transition-colors"
        title="Delete"
      >
        {loading === "delete" ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
      </button>
    </div>
  );
}
