"use client";

import { signOut } from "next-auth/react";
import { LogOut, User } from "lucide-react";
import { ThemeToggle } from "@/components/ui/ThemeToggle";

type Props = {
  user: { name?: string | null; email?: string | null; image?: string | null };
};

export function AdminHeader({ user }: Props) {
  return (
    <header className="h-16 flex items-center justify-between px-6 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex-shrink-0">
      <div className="flex items-center gap-2 md:hidden">
        <span className="text-lg font-bold gradient-text">Admin Panel</span>
      </div>

      <div className="flex-1" />

      <div className="flex items-center gap-3">
        <ThemeToggle />

        <div className="flex items-center gap-2 pl-3 border-l border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-indigo-600 flex items-center justify-center text-white">
              {user.name ? (
                <span className="text-xs font-bold">{user.name.charAt(0).toUpperCase()}</span>
              ) : (
                <User size={14} />
              )}
            </div>
            <span className="hidden sm:block text-slate-700 dark:text-slate-300 font-medium max-w-[120px] truncate">
              {user.name ?? user.email}
            </span>
          </div>

          <button
            onClick={() => signOut({ callbackUrl: "/admin/login" })}
            className="btn-ghost p-2 text-slate-500 hover:text-red-500 transition-colors"
            title="Sign out"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  );
}
