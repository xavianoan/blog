import Link from "next/link";
import { Github, Twitter, Linkedin, Mail } from "lucide-react";
import type { SiteSettings } from "@/lib/settings";

type FooterProps = {
  settings: SiteSettings;
};

export function Footer({ settings }: FooterProps) {
  const socials = [
    { href: settings.githubUrl, icon: Github, label: "GitHub" },
    { href: settings.twitterUrl, icon: Twitter, label: "Twitter" },
    { href: settings.linkedinUrl, icon: Linkedin, label: "LinkedIn" },
    { href: `mailto:${settings.contactEmail}`, icon: Mail, label: "Email" },
  ].filter((s) => s.href && s.href !== "mailto:");

  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <Link href="/" className="text-xl font-bold gradient-text">
              {settings.siteTitle}
            </Link>
            <p className="mt-3 text-sm text-slate-500 dark:text-slate-400 max-w-xs">
              {settings.siteDescription}
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4">
              Navigation
            </h3>
            <ul className="space-y-2">
              {[
                { href: "/", label: "Home" },
                { href: "/about", label: "About" },
                { href: "/projects", label: "Projects" },
                { href: "/blog", label: "Blog" },
                { href: "/contact", label: "Contact" },
              ].map(({ href, label }) => (
                <li key={href}>
                  <Link
                    href={href}
                    className="text-sm text-slate-500 dark:text-slate-400 hover:text-brand-500 dark:hover:text-brand-400 transition-colors"
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4">
              Connect
            </h3>
            <div className="flex gap-3">
              {socials.map(({ href, icon: Icon, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950 dark:hover:text-brand-400 transition-colors"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
            {settings.contactEmail && (
              <p className="mt-4 text-sm text-slate-500 dark:text-slate-400">
                <a href={`mailto:${settings.contactEmail}`} className="hover:text-brand-500 transition-colors">
                  {settings.contactEmail}
                </a>
              </p>
            )}
          </div>
        </div>

        <div className="mt-10 pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-500 dark:text-slate-400">{settings.footerText}</p>
          <Link
            href="/admin"
            className="text-xs text-slate-400 dark:text-slate-600 hover:text-slate-500 transition-colors"
          >
            Admin
          </Link>
        </div>
      </div>
    </footer>
  );
}
