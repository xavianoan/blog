import { prisma } from "@/lib/prisma";
import { cache } from "react";

export type SiteSettings = {
  siteTitle: string;
  siteDescription: string;
  authorName: string;
  authorBio: string;
  authorAvatar: string;
  twitterUrl: string;
  githubUrl: string;
  linkedinUrl: string;
  contactEmail: string;
  footerText: string;
  heroTitle: string;
  heroSubtitle: string;
  heroDescription: string;
  aboutTitle: string;
  aboutContent: string;
  skills: string[];
};

const defaultSettings: SiteSettings = {
  siteTitle: "My Portfolio & Blog",
  siteDescription: "Personal portfolio and blog",
  authorName: "Your Name",
  authorBio: "Full-stack developer",
  authorAvatar: "",
  twitterUrl: "",
  githubUrl: "",
  linkedinUrl: "",
  contactEmail: "",
  footerText: "© 2025. All rights reserved.",
  heroTitle: "Hi, I'm Your Name 👋",
  heroSubtitle: "Full-Stack Developer",
  heroDescription: "I build fast, accessible web experiences.",
  aboutTitle: "About Me",
  aboutContent: "<p>Write something about yourself here...</p>",
  skills: [],
};

export const getSiteSettings = cache(async (): Promise<SiteSettings> => {
  try {
    const rows = await prisma.siteSetting.findMany();
    const map: Record<string, string> = {};
    for (const row of rows) {
      map[row.key] = row.value ?? "";
    }

    return {
      siteTitle: map.siteTitle ?? defaultSettings.siteTitle,
      siteDescription: map.siteDescription ?? defaultSettings.siteDescription,
      authorName: map.authorName ?? defaultSettings.authorName,
      authorBio: map.authorBio ?? defaultSettings.authorBio,
      authorAvatar: map.authorAvatar ?? defaultSettings.authorAvatar,
      twitterUrl: map.twitterUrl ?? defaultSettings.twitterUrl,
      githubUrl: map.githubUrl ?? defaultSettings.githubUrl,
      linkedinUrl: map.linkedinUrl ?? defaultSettings.linkedinUrl,
      contactEmail: map.contactEmail ?? defaultSettings.contactEmail,
      footerText: map.footerText ?? defaultSettings.footerText,
      heroTitle: map.heroTitle ?? defaultSettings.heroTitle,
      heroSubtitle: map.heroSubtitle ?? defaultSettings.heroSubtitle,
      heroDescription: map.heroDescription ?? defaultSettings.heroDescription,
      aboutTitle: map.aboutTitle ?? defaultSettings.aboutTitle,
      aboutContent: map.aboutContent ?? defaultSettings.aboutContent,
      skills: map.skills ? (JSON.parse(map.skills) as string[]) : defaultSettings.skills,
    };
  } catch {
    return defaultSettings;
  }
});
