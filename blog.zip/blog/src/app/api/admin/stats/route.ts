import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [totalPosts, publishedPosts, draftPosts, totalProjects, totalMessages, unreadMessages] =
    await Promise.all([
      prisma.post.count(),
      prisma.post.count({ where: { status: "PUBLISHED" } }),
      prisma.post.count({ where: { status: "DRAFT" } }),
      prisma.project.count(),
      prisma.message.count(),
      prisma.message.count({ where: { status: "UNREAD" } }),
    ]);

  return NextResponse.json({
    totalPosts,
    publishedPosts,
    draftPosts,
    totalProjects,
    totalMessages,
    unreadMessages,
  });
}
