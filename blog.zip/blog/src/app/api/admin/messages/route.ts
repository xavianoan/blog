import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = req.nextUrl;
  const page = parseInt(searchParams.get("page") ?? "1");
  const perPage = 20;
  const status = searchParams.get("status") ?? undefined;

  const where: Parameters<typeof prisma.message.findMany>[0]["where"] = {};
  if (status) where.status = status as "UNREAD" | "READ" | "REPLIED" | "ARCHIVED";

  const [messages, total] = await Promise.all([
    prisma.message.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    prisma.message.count({ where }),
  ]);

  return NextResponse.json({ messages, total });
}
