import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { generateSlug } from "@/lib/utils";

const schema = z.object({
  title: z.string().min(1).max(500),
  slug: z.string().optional(),
  description: z.string().min(1),
  content: z.string().optional(),
  coverImage: z.string().optional(),
  demoUrl: z.string().optional(),
  githubUrl: z.string().optional(),
  techStack: z.array(z.string()).default([]),
  featured: z.boolean().default(false),
  order: z.number().int().default(0),
  status: z.enum(["DRAFT", "PUBLISHED"]).default("PUBLISHED"),
});

type RouteParams = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, { params }: RouteParams) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const slug = data.slug?.trim() || generateSlug(data.title);

    const slugConflict = await prisma.project.findFirst({
      where: { slug, NOT: { id } },
    });
    if (slugConflict) {
      return NextResponse.json({ error: "Slug already exists" }, { status: 409 });
    }

    const project = await prisma.project.update({
      where: { id },
      data: {
        ...data,
        slug,
        techStack: JSON.stringify(data.techStack),
      },
    });
    return NextResponse.json(project);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 422 });
    }
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: RouteParams) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  await prisma.project.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
