import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { Plus, Pencil } from "lucide-react";
import { DeleteProjectButton } from "@/components/admin/DeleteProjectButton";

export default async function AdminProjectsPage() {
  const projects = await prisma.project.findMany({
    orderBy: [{ order: "asc" }, { createdAt: "desc" }],
  });

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Projects</h1>
          <p className="text-sm text-slate-500 mt-1">{projects.length} total projects</p>
        </div>
        <Link href="/admin/projects/new" className="btn-primary">
          <Plus size={16} /> New Project
        </Link>
      </div>

      {projects.length === 0 ? (
        <div className="card p-16 text-center">
          <p className="text-slate-400 mb-4">No projects yet</p>
          <Link href="/admin/projects/new" className="btn-primary inline-flex">
            Add your first project
          </Link>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                  <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Title</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400 hidden md:table-cell">Status</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-600 dark:text-slate-400 hidden lg:table-cell">Featured</th>
                  <th className="text-right px-4 py-3 font-medium text-slate-600 dark:text-slate-400">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {projects.map((project) => {
                  const techs: string[] = project.techStack
                    ? (JSON.parse(project.techStack) as string[])
                    : [];
                  return (
                    <tr key={project.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-medium text-slate-900 dark:text-white">{project.title}</div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {techs.slice(0, 3).map((t) => (
                            <span key={t} className="tag-chip text-xs">{t}</span>
                          ))}
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                          project.status === "PUBLISHED"
                            ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                            : "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400"
                        }`}>
                          {project.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell text-slate-500 dark:text-slate-400 text-xs">
                        {project.featured ? "✓" : "—"}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Link
                            href={`/admin/projects/${project.id}/edit`}
                            className="btn-ghost p-2 text-slate-400"
                            title="Edit"
                          >
                            <Pencil size={14} />
                          </Link>
                          <DeleteProjectButton id={project.id} title={project.title} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
