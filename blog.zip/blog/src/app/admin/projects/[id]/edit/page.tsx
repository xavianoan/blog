import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { ProjectForm } from "@/components/admin/ProjectForm";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

type Props = { params: Promise<{ id: string }> };

export default async function EditProjectPage({ params }: Props) {
  const { id } = await params;
  const project = await prisma.project.findUnique({ where: { id } });
  if (!project) notFound();

  const techStack: string[] = project.techStack
    ? (JSON.parse(project.techStack) as string[])
    : [];

  return (
    <div className="max-w-6xl space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/admin/projects" className="btn-ghost p-2">
          <ArrowLeft size={18} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Edit Project</h1>
          <p className="text-sm text-slate-500 mt-0.5 font-mono">{project.slug}</p>
        </div>
      </div>
      <ProjectForm
        initialData={{
          id: project.id,
          title: project.title,
          slug: project.slug,
          description: project.description,
          content: project.content,
          coverImage: project.coverImage,
          demoUrl: project.demoUrl,
          githubUrl: project.githubUrl,
          techStack,
          featured: project.featured,
          order: project.order,
          status: project.status,
        }}
      />
    </div>
  );
}
