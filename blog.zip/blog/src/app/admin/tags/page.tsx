import { prisma } from "@/lib/prisma";
import { TagsManager } from "@/components/admin/TagsManager";

export default async function AdminTagsPage() {
  const tags = await prisma.tag.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { posts: true } } },
  });

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Tags</h1>
        <p className="text-sm text-slate-500 mt-1">{tags.length} tags</p>
      </div>
      <TagsManager initialTags={tags} />
    </div>
  );
}
