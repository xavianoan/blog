import { prisma } from "@/lib/prisma";
import { FileText, Briefcase, MessageSquare, Eye, TrendingUp, Clock } from "lucide-react";
import Link from "next/link";
import { formatDate } from "@/lib/utils";

export default async function AdminDashboard() {
  const [
    totalPosts,
    publishedPosts,
    draftPosts,
    totalProjects,
    totalMessages,
    unreadMessages,
    recentPosts,
    recentMessages,
  ] = await Promise.all([
    prisma.post.count(),
    prisma.post.count({ where: { status: "PUBLISHED" } }),
    prisma.post.count({ where: { status: "DRAFT" } }),
    prisma.project.count(),
    prisma.message.count(),
    prisma.message.count({ where: { status: "UNREAD" } }),
    prisma.post.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      include: { category: true },
    }),
    prisma.message.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
    }),
  ]);

  const stats = [
    {
      label: "Total Posts",
      value: totalPosts,
      sub: `${publishedPosts} published · ${draftPosts} draft`,
      icon: FileText,
      color: "text-blue-500",
      bg: "bg-blue-50 dark:bg-blue-950",
      href: "/admin/posts",
    },
    {
      label: "Projects",
      value: totalProjects,
      sub: "All projects",
      icon: Briefcase,
      color: "text-emerald-500",
      bg: "bg-emerald-50 dark:bg-emerald-950",
      href: "/admin/projects",
    },
    {
      label: "Messages",
      value: totalMessages,
      sub: `${unreadMessages} unread`,
      icon: MessageSquare,
      color: "text-brand-500",
      bg: "bg-brand-50 dark:bg-brand-950",
      href: "/admin/messages",
    },
    {
      label: "Total Views",
      value: "—",
      sub: "Coming soon",
      icon: Eye,
      color: "text-amber-500",
      bg: "bg-amber-50 dark:bg-amber-950",
      href: "/admin/posts",
    },
  ];

  return (
    <div className="space-y-8 max-w-6xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
          Welcome back! Here&apos;s an overview of your site.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        {stats.map(({ label, value, sub, icon: Icon, color, bg, href }) => (
          <Link key={label} href={href}>
            <div className="card p-6 flex items-start gap-4 hover:border-brand-300 dark:hover:border-brand-700 transition-colors cursor-pointer">
              <div className={`p-3 rounded-xl ${bg}`}>
                <Icon size={22} className={color} />
              </div>
              <div className="min-w-0">
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</p>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">{sub}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Posts */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp size={18} className="text-brand-500" />
              Recent Posts
            </h2>
            <Link href="/admin/posts/new" className="btn-primary text-xs px-3 py-1.5">
              + New Post
            </Link>
          </div>
          {recentPosts.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">No posts yet</p>
          ) : (
            <ul className="space-y-3">
              {recentPosts.map((post) => (
                <li key={post.id} className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <Link
                      href={`/admin/posts/${post.id}/edit`}
                      className="text-sm font-medium text-slate-800 dark:text-slate-200 hover:text-brand-500 transition-colors line-clamp-1"
                    >
                      {post.title}
                    </Link>
                    <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                      <Clock size={11} />
                      {formatDate(post.createdAt)}
                      {post.category && (
                        <span className="ml-2 tag-chip px-2 py-0.5 text-xs">{post.category.name}</span>
                      )}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0 ${
                      post.status === "PUBLISHED"
                        ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                        : "bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400"
                    }`}
                  >
                    {post.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Recent Messages */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <MessageSquare size={18} className="text-brand-500" />
              Recent Messages
              {unreadMessages > 0 && (
                <span className="ml-1 bg-brand-500 text-white text-xs rounded-full px-2 py-0.5">
                  {unreadMessages}
                </span>
              )}
            </h2>
            <Link href="/admin/messages" className="text-xs text-brand-500 hover:underline">
              View all
            </Link>
          </div>
          {recentMessages.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">No messages yet</p>
          ) : (
            <ul className="space-y-3">
              {recentMessages.map((msg) => (
                <li key={msg.id}>
                  <Link
                    href="/admin/messages"
                    className="block hover:bg-slate-50 dark:hover:bg-slate-800 -mx-3 px-3 py-2 rounded-lg transition-colors"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                        {msg.name}
                      </span>
                      {msg.status === "UNREAD" && (
                        <span className="w-2 h-2 rounded-full bg-brand-500 flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{msg.subject ?? msg.body}</p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      <Clock size={11} className="inline mr-1" />
                      {formatDate(msg.createdAt)}
                    </p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
