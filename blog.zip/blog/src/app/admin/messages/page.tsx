import { prisma } from "@/lib/prisma";
import { formatDate } from "@/lib/utils";
import { MessageActions } from "@/components/admin/MessageActions";

export default async function AdminMessagesPage() {
  const messages = await prisma.message.findMany({
    orderBy: { createdAt: "desc" },
  });

  const unread = messages.filter((m) => m.status === "UNREAD").length;

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Messages</h1>
        <p className="text-sm text-slate-500 mt-1">
          {messages.length} total · {unread} unread
        </p>
      </div>

      {messages.length === 0 ? (
        <div className="card p-16 text-center">
          <p className="text-slate-400">No messages yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`card p-5 ${msg.status === "UNREAD" ? "border-brand-200 dark:border-brand-800" : ""}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-semibold text-slate-900 dark:text-white">{msg.name}</span>
                    <a href={`mailto:${msg.email}`} className="text-sm text-brand-500 hover:underline">
                      {msg.email}
                    </a>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      msg.status === "UNREAD"
                        ? "bg-brand-100 text-brand-700 dark:bg-brand-950 dark:text-brand-400"
                        : msg.status === "REPLIED"
                        ? "bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400"
                        : msg.status === "ARCHIVED"
                        ? "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"
                        : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                    }`}>
                      {msg.status}
                    </span>
                    <span className="text-xs text-slate-400">{formatDate(msg.createdAt)}</span>
                  </div>
                  {msg.subject && (
                    <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mt-1">
                      {msg.subject}
                    </p>
                  )}
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 whitespace-pre-wrap">
                    {msg.body}
                  </p>
                </div>
                <MessageActions id={msg.id} status={msg.status} email={msg.email} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
