import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { PostForm } from "@/components/admin/PostForm";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

type Props = { params: Promise<{ id: string }> };

export default async function EditPostPage({ params }: Props) {
  const { id } = await params;
  const [post, categories, tags] = await Promise.all([
    prisma.post.findUnique({
      where: { id },
      include: { tags: { include: { tag: true } } },
    }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
    prisma.tag.findMany({ orderBy: { name: "asc" } }),
  ]);

  if (!post) notFound();

  return (
    <div className="max-w-6xl space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/admin/posts" className="btn-ghost p-2">
          <ArrowLeft size={18} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Edit Post</h1>
          <p className="text-sm text-slate-500 mt-0.5 font-mono">{post.slug}</p>
        </div>
      </div>
      <PostForm
        categories={categories}
        tags={tags}
        initialData={{
          id: post.id,
          title: post.title,
          slug: post.slug,
          excerpt: post.excerpt,
          content: post.content,
          coverImage: post.coverImage,
          status: post.status,
          featured: post.featured,
          categoryId: post.categoryId,
          tagIds: post.tags.map((t) => t.tagId),
          metaTitle: post.metaTitle,
          metaDescription: post.metaDescription,
        }}
      />
    </div>
  );
}
