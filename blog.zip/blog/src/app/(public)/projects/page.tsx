import { prisma } from "@/lib/prisma";
import Link from "next/link";
import Image from "next/image";
import { ExternalLink, Github } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Projects",
  description: "A showcase of my work and side projects.",
};

export default async function ProjectsPage() {
  const projects = await prisma.project.findMany({
    where: { status: "PUBLISHED" },
    orderBy: [{ order: "asc" }, { createdAt: "desc" }],
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="mb-12">
        <h1 className="section-title">Projects</h1>
        <p className="section-subtitle">Things I&apos;ve built — open-source and otherwise.</p>
      </div>

      {projects.length === 0 ? (
        <div className="card p-16 text-center">
          <p className="text-slate-500 dark:text-slate-400">No projects yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project) => {
            const techs: string[] = project.techStack
              ? (JSON.parse(project.techStack) as string[])
              : [];
            return (
              <div key={project.id} className="card overflow-hidden group flex flex-col">
                {project.coverImage && (
                  <div className="relative h-52 overflow-hidden">
                    <Image
                      src={project.coverImage}
                      alt={project.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}
                <div className="p-6 flex flex-col flex-1">
                  <h2 className="font-bold text-xl text-slate-900 dark:text-white mb-2">
                    {project.title}
                  </h2>
                  <p className="text-slate-500 dark:text-slate-400 text-sm flex-1 mb-4">
                    {project.description}
                  </p>
                  {techs.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-5">
                      {techs.map((tech) => (
                        <span key={tech} className="tag-chip">
                          {tech}
                        </span>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-3 mt-auto">
                    {project.demoUrl && (
                      <a
                        href={project.demoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-primary text-sm"
                      >
                        <ExternalLink size={14} /> Live Demo
                      </a>
                    )}
                    {project.githubUrl && (
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-secondary text-sm"
                      >
                        <Github size={14} /> GitHub
                      </a>
                    )}
                    <Link
                      href={`/projects/${project.slug}`}
                      className="btn-ghost text-sm ml-auto"
                    >
                      Details →
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
