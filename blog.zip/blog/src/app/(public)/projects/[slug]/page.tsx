import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ExternalLink, Github } from "lucide-react";
import type { Metadata } from "next";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const project = await prisma.project.findUnique({ where: { slug } });
  if (!project) return { title: "Not Found" };
  return {
    title: project.title,
    description: project.description,
  };
}

export async function generateStaticParams() {
  const projects = await prisma.project.findMany({
    where: { status: "PUBLISHED" },
    select: { slug: true },
  });
  return projects.map((p) => ({ slug: p.slug }));
}

export default async function ProjectDetailPage({ params }: Props) {
  const { slug } = await params;

  const project = await prisma.project.findUnique({ where: { slug } });
  if (!project || project.status !== "PUBLISHED") notFound();

  const techs: string[] = project.techStack
    ? (JSON.parse(project.techStack) as string[])
    : [];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <Link
        href="/projects"
        className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-brand-500 transition-colors mb-8"
      >
        <ArrowLeft size={16} /> Back to Projects
      </Link>

      {project.coverImage && (
        <div className="relative h-64 md:h-96 rounded-2xl overflow-hidden mb-10 shadow-lg">
          <Image
            src={project.coverImage}
            alt={project.title}
            fill
            className="object-cover"
            priority
          />
        </div>
      )}

      <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-slate-900 dark:text-white mb-4">
        {project.title}
      </h1>

      <p className="text-lg text-slate-600 dark:text-slate-400 mb-6">
        {project.description}
      </p>

      {techs.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-8">
          {techs.map((tech) => (
            <span key={tech} className="tag-chip">
              {tech}
            </span>
          ))}
        </div>
      )}

      <div className="flex gap-3 mb-10">
        {project.demoUrl && (
          <a
            href={project.demoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            <ExternalLink size={16} /> Live Demo
          </a>
        )}
        {project.githubUrl && (
          <a
            href={project.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary"
          >
            <Github size={16} /> GitHub
          </a>
        )}
      </div>

      {project.content && (
        <div
          className="prose-blog"
          dangerouslySetInnerHTML={{ __html: project.content }}
        />
      )}
    </div>
  );
}
