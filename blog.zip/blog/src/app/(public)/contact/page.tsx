import type { Metadata } from "next";
import { getSiteSettings } from "@/lib/settings";
import { ContactForm } from "@/components/contact/ContactForm";
import { Mail, Github, Twitter, Linkedin } from "lucide-react";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch.",
};

export default async function ContactPage() {
  const settings = await getSiteSettings();

  const socials = [
    { href: settings.githubUrl, icon: Github, label: "GitHub" },
    { href: settings.twitterUrl, icon: Twitter, label: "Twitter" },
    { href: settings.linkedinUrl, icon: Linkedin, label: "LinkedIn" },
  ].filter((s) => s.href);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="mb-12">
        <h1 className="section-title">Get in Touch</h1>
        <p className="section-subtitle">
          Have a question or want to work together? Drop me a message.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
        <div className="lg:col-span-2 space-y-6">
          {settings.contactEmail && (
            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-xl bg-brand-50 dark:bg-brand-950 text-brand-500">
                <Mail size={20} />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">Email</h3>
                <a
                  href={`mailto:${settings.contactEmail}`}
                  className="text-sm text-slate-500 dark:text-slate-400 hover:text-brand-500 transition-colors"
                >
                  {settings.contactEmail}
                </a>
              </div>
            </div>
          )}

          {socials.length > 0 && (
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4">
                Connect
              </h3>
              <div className="flex gap-3">
                {socials.map(({ href, icon: Icon, label }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950 dark:hover:text-brand-400 transition-colors"
                  >
                    <Icon size={20} />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-3">
          <div className="card p-6 md:p-8">
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  );
}
