import { getSiteSettings } from "@/lib/settings";
import Image from "next/image";
import type { Metadata } from "next";

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  return {
    title: "About",
    description: `Learn more about ${settings.authorName}.`,
  };
}

export default async function AboutPage() {
  const settings = await getSiteSettings();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        <div className="md:col-span-1">
          {settings.authorAvatar ? (
            <Image
              src={settings.authorAvatar}
              alt={settings.authorName}
              width={280}
              height={280}
              className="rounded-2xl shadow-lg w-full"
            />
          ) : (
            <div className="w-full aspect-square rounded-2xl bg-gradient-to-br from-brand-400 to-indigo-600 flex items-center justify-center shadow-lg">
              <span className="text-6xl font-bold text-white">
                {settings.authorName.charAt(0).toUpperCase()}
              </span>
            </div>
          )}

          {settings.skills.length > 0 && (
            <div className="mt-8">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-4">
                Skills
              </h3>
              <div className="flex flex-wrap gap-2">
                {settings.skills.map((skill) => (
                  <span key={skill} className="tag-chip">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="md:col-span-2">
          <p className="text-sm text-brand-500 font-semibold uppercase tracking-widest mb-3">
            About Me
          </p>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-6">
            {settings.aboutTitle}
          </h1>
          <div
            className="prose-blog"
            dangerouslySetInnerHTML={{ __html: settings.aboutContent }}
          />
        </div>
      </div>
    </div>
  );
}
