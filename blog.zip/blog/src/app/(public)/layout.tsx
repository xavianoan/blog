import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { getSiteSettings } from "@/lib/settings";

export default async function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const settings = await getSiteSettings();

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar siteTitle={settings.siteTitle} />
      <main className="flex-1 pt-16">{children}</main>
      <Footer settings={settings} />
    </div>
  );
}
