import { getSiteSettings } from "@/lib/settings";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Github, Twitter, Linkedin, Mail, Calendar, Clock } from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { Metadata } from "next";

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  return {
    title: settings.siteTitle,
    description: settings.siteDescription,
  };
}

export default async function HomePage() {
  const settings = await getSiteSettings();

  const [featuredPosts, featuredProjects] = await Promise.all([
    prisma.post.findMany({
      where: { status: "PUBLISHED", featured: true },
      orderBy: { publishedAt: "desc" },
      take: 3,
      include: { category: true, tags: { include: { tag: true } } },
    }),
    prisma.project.findMany({
      where: { status: "PUBLISHED", featured: true },
      orderBy: { order: "asc" },
      take: 3,
    }),
  ]);

  const socials = [
    { href: settings.githubUrl, icon: Github, label: "GitHub" },
    { href: settings.twitterUrl, icon: Twitter, label: "Twitter" },
    { href: settings.linkedinUrl, icon: Linkedin, label: "LinkedIn" },
    { href: `mailto:${settings.contactEmail}`, icon: Mail, label: "Email" },
  ].filter((s) => s.href && s.href !== "mailto:");

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-50 via-white to-indigo-50 dark:from-slate-950 dark:via-slate-950 dark:to-indigo-950/30" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-brand-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-400/10 rounded-full blur-3xl" />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <div className="max-w-3xl">
            {settings.authorAvatar && (
              <div className="mb-8">
                <Image
                  src={settings.authorAvatar}
                  alt={settings.authorName}
                  width={80}
                  height={80}
                  className="rounded-2xl border-2 border-white dark:border-slate-800 shadow-lg"
                />
              </div>
            )}
            <p className="text-brand-500 font-semibold mb-4 text-sm uppercase tracking-widest animate-fade-in">
              Welcome to my space
            </p>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-slate-900 dark:text-white mb-6 animate-slide-up">
              {settings.heroTitle}
            </h1>
            <p className="text-xl md:text-2xl text-brand-500 font-medium mb-6">
              {settings.heroSubtitle}
            </p>
            <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 max-w-2xl leading-relaxed">
              {settings.heroDescription}
            </p>
            <div className="flex flex-wrap gap-4 items-center">
              <Link href="/projects" className="btn-primary text-base px-6 py-3">
                View My Work <ArrowRight size={18} />
              </Link>
              <Link href="/contact" className="btn-secondary text-base px-6 py-3">
                Get in Touch
              </Link>
            </div>
            {socials.length > 0 && (
              <div className="flex gap-3 mt-8">
                {socials.map(({ href, icon: Icon, label }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    className="p-2.5 rounded-xl bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950 dark:hover:text-brand-400 border border-slate-200 dark:border-slate-700 transition-all shadow-sm"
                  >
                    <Icon size={18} />
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Skills */}
      {settings.skills.length > 0 && (
        <section className="py-16 bg-slate-50 dark:bg-slate-900/50 border-y border-slate-200 dark:border-slate-800">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <p className="text-center text-sm text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-8">
              Technologies I work with
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              {settings.skills.map((skill) => (
                <span key={skill} className="tag-chip text-sm px-4 py-1.5">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Projects */}
      {featuredProjects.length > 0 && (
        <section className="py-20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="section-title">Featured Projects</h2>
                <p className="section-subtitle">A selection of my recent work.</p>
              </div>
              <Link href="/projects" className="btn-ghost hidden sm:inline-flex">
                All projects <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProjects.map((project) => {
                const techs: string[] = project.techStack
                  ? (JSON.parse(project.techStack) as string[])
                  : [];
                return (
                  <Link key={project.id} href={`/projects/${project.slug}`}>
                    <div className="card p-6 h-full flex flex-col group cursor-pointer">
                      {project.coverImage && (
                        <div className="relative h-40 -mx-6 -mt-6 mb-5 rounded-t-2xl overflow-hidden">
                          <Image
                            src={project.coverImage}
                            alt={project.title}
                            fill
                            className="object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      )}
                      <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-2 group-hover:text-brand-500 transition-colors">
                        {project.title}
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 flex-1 line-clamp-3">
                        {project.description}
                      </p>
                      {techs.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-4">
                          {techs.slice(0, 4).map((tech) => (
                            <span key={tech} className="tag-chip">{tech}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Featured Blog Posts */}
      {featuredPosts.length > 0 && (
        <section className="py-20 bg-slate-50 dark:bg-slate-900/30">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="section-title">Latest Articles</h2>
                <p className="section-subtitle">Thoughts, tutorials and ideas.</p>
              </div>
              <Link href="/blog" className="btn-ghost hidden sm:inline-flex">
                All articles <ArrowRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {featuredPosts.map((post) => (
                <Link key={post.id} href={`/blog/${post.slug}`}>
                  <div className="card overflow-hidden group cursor-pointer h-full flex flex-col">
                    {post.coverImage && (
                      <div className="relative h-44 overflow-hidden">
                        <Image
                          src={post.coverImage}
                          alt={post.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    )}
                    <div className="p-6 flex flex-col flex-1">
                      {post.category && (
                        <span
                          className="text-xs font-semibold uppercase tracking-wider mb-3"
                          style={{ color: post.category.color ?? "#6366f1" }}
                        >
                          {post.category.name}
                        </span>
                      )}
                      <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-3 line-clamp-2 group-hover:text-brand-500 transition-colors">
                        {post.title}
                      </h3>
                      {post.excerpt && (
                        <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 flex-1">
                          {post.excerpt}
                        </p>
                      )}
                      <div className="flex items-center gap-4 mt-4 text-xs text-slate-400">
                        {post.publishedAt && (
                          <span className="flex items-center gap-1">
                            <Calendar size={12} />
                            {formatDate(post.publishedAt)}
                          </span>
                        )}
                        {post.readingTime && (
                          <span className="flex items-center gap-1">
                            <Clock size={12} />
                            {post.readingTime} min read
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="py-24">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4 text-slate-900 dark:text-white">
            Let&apos;s work together
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-lg mb-8">
            Have a project in mind? I&apos;d love to hear about it.
          </p>
          <Link href="/contact" className="btn-primary text-base px-8 py-3.5">
            Say Hello <Mail size={18} />
          </Link>
        </div>
      </section>
    </>
  );
}
