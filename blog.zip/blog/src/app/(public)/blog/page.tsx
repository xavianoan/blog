import { prisma } from "@/lib/prisma";
import Link from "next/link";
import Image from "next/image";
import { formatDate } from "@/lib/utils";
import { Calendar, Clock, Search } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Blog",
  description: "Articles, tutorials and thoughts.",
};

type SearchParams = { category?: string; tag?: string; q?: string; page?: string };

export default async function BlogPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const page = parseInt(params.page ?? "1");
  const perPage = 9;
  const skip = (page - 1) * perPage;

  const where: Parameters<typeof prisma.post.findMany>[0]["where"] = {
    status: "PUBLISHED",
  };

  if (params.category) {
    where.category = { slug: params.category };
  }

  if (params.tag) {
    where.tags = { some: { tag: { slug: params.tag } } };
  }

  if (params.q) {
    where.OR = [
      { title: { contains: params.q } },
      { excerpt: { contains: params.q } },
    ];
  }

  const [posts, total, categories] = await Promise.all([
    prisma.post.findMany({
      where,
      orderBy: { publishedAt: "desc" },
      skip,
      take: perPage,
      include: { category: true, tags: { include: { tag: true } } },
    }),
    prisma.post.count({ where }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  const totalPages = Math.ceil(total / perPage);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="mb-12">
        <h1 className="section-title">Blog</h1>
        <p className="section-subtitle">Thoughts, tutorials and ideas.</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar */}
        <aside className="lg:w-64 flex-shrink-0 space-y-6">
          {/* Search */}
          <div className="card p-4">
            <form method="GET">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="text"
                  name="q"
                  defaultValue={params.q}
                  placeholder="Search articles..."
                  className="input pl-9"
                />
              </div>
            </form>
          </div>

          {/* Categories */}
          {categories.length > 0 && (
            <div className="card p-4">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100 uppercase tracking-wider mb-3">
                Categories
              </h3>
              <ul className="space-y-1">
                <li>
                  <Link
                    href="/blog"
                    className={`block px-3 py-1.5 rounded-lg text-sm transition-colors ${
                      !params.category
                        ? "bg-brand-50 dark:bg-brand-950 text-brand-600 dark:text-brand-400"
                        : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    }`}
                  >
                    All
                  </Link>
                </li>
                {categories.map((cat) => (
                  <li key={cat.id}>
                    <Link
                      href={`/blog?category=${cat.slug}`}
                      className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-sm transition-colors ${
                        params.category === cat.slug
                          ? "bg-brand-50 dark:bg-brand-950 text-brand-600 dark:text-brand-400"
                          : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: cat.color ?? "#6366f1" }}
                        />
                        {cat.name}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>

        {/* Posts Grid */}
        <div className="flex-1">
          {posts.length === 0 ? (
            <div className="card p-16 text-center">
              <p className="text-slate-500 dark:text-slate-400">No articles found.</p>
              <Link href="/blog" className="btn-primary mt-4 inline-flex">
                Clear filters
              </Link>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <Link key={post.id} href={`/blog/${post.slug}`}>
                    <article className="card overflow-hidden group cursor-pointer h-full flex flex-col">
                      {post.coverImage && (
                        <div className="relative h-44 overflow-hidden">
                          <Image
                            src={post.coverImage}
                            alt={post.title}
                            fill
                            className="object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      )}
                      <div className="p-5 flex flex-col flex-1">
                        {post.category && (
                          <span
                            className="text-xs font-semibold uppercase tracking-wider mb-2"
                            style={{ color: post.category.color ?? "#6366f1" }}
                          >
                            {post.category.name}
                          </span>
                        )}
                        <h2 className="font-bold text-slate-900 dark:text-white mb-2 line-clamp-2 group-hover:text-brand-500 transition-colors">
                          {post.title}
                        </h2>
                        {post.excerpt && (
                          <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 flex-1">
                            {post.excerpt}
                          </p>
                        )}
                        <div className="flex items-center gap-3 mt-3 text-xs text-slate-400">
                          {post.publishedAt && (
                            <span className="flex items-center gap-1">
                              <Calendar size={11} />
                              {formatDate(post.publishedAt)}
                            </span>
                          )}
                          {post.readingTime && (
                            <span className="flex items-center gap-1">
                              <Clock size={11} />
                              {post.readingTime} min
                            </span>
                          )}
                        </div>
                      </div>
                    </article>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center gap-2 mt-12">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                    <Link
                      key={p}
                      href={`/blog?page=${p}${params.category ? `&category=${params.category}` : ""}${params.q ? `&q=${params.q}` : ""}`}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                        p === page
                          ? "bg-brand-500 text-white"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                      }`}
                    >
                      {p}
                    </Link>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
